//
//  TableCellContent.swift
//  My Planet
//
//  Created by SaitoYayoi on 2020/5/9.
//  Copyright © 2020 KanoYuta. All rights reserved.
//

import UIKit

class TableCellContent: NSObject {
    var image: String?
    var title: String?
}
